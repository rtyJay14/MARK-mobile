package com.journeytech.mark.mark.model;

/**
 * Created by rtyJa on 24/07/2017.
 */

public class Navigation {
Double latitude = 0.0;
    Double longitude = 0.0;

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }
}
