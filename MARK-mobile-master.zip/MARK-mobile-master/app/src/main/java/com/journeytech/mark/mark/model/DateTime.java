package com.journeytech.mark.mark.model;

/**
 * Created by rtyJa on 03/08/2017.
 */

public class DateTime {
    String date = "";
    String time = "";
    String dateTime = "";

    public String getDateTime() {
        return dateTime;
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
