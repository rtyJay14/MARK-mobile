package com.journeytech.mark.mark.model;

/**
 * Created by rtyJa on 19/07/2017.
 */

public class Proximity {
    Double latitude;

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    Double longitude;
}
