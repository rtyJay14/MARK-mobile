package com.journeytech.mark.mark.model;

/**
 * Created by rtyJa on 26/07/2017.
 */

public class SearchSuggestion {
    String get = "";

    public String getGet() {
        return get;
    }

    public void setGet(String get) {
        this.get = get;
    }
}
